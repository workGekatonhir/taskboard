import React from 'react';
import TaskBoard from '../containers/TaskBoard';

const App = () => {
  return (
      <TaskBoard />
  )
};

export default  App;